import java.util.ArrayList;
import java.util.Scanner;

public class App {
    ArrayList<Person> x = new ArrayList<Person>();
    int firstChoices;
    int secondChoices;
    Scanner sc1 = new Scanner(System.in);
    Scanner sc2 = new Scanner(System.in);
    
    public static void main(String[] args) throws Exception {
        new App();
    }

    void inputPegawai(){
        for (int i = 1; i <= firstChoices; i++) {
            System.out.printf("Masukkan nama pegawai %d [1-20 karakter]: ",i);
            String nama = sc2.nextLine();
            System.out.printf("Masukkan nama pegawai %d [300-500]: ",i);
            int gaji = 0; 
            gaji = sc1.nextInt();
            x.set(i, new Person(nama, gaji));
            nama = "";
            gaji = 0;
        }
    }

    void MainMenu(){
        System.out.println("Menu:");
        System.out.println("1. Urut Nama Ascending");
        System.out.println("2. Urut Gaji Descending");
        System.out.println("3. Exit");
        System.out.printf("Pilihan Anda [1-3]: ");
        secondChoices = sc1.nextInt();
    }

    App(){
        System.out.printf("Masukkan jumlah pegawai [3-5]: ");
        do {
            try {
                firstChoices = sc1.nextInt();
            } catch (Exception e) {
                // TODO: handle exception
            }
        } while (firstChoices < 3 || firstChoices > 5);
        System.out.println("");
        inputPegawai();
        MainMenu();
    }
}
