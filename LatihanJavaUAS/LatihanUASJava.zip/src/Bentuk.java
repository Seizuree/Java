abstract public class Bentuk {
  float hitungLuas() {
    return 0;
  }

  float hitungKeliling() {
    return 0;
  }
}
