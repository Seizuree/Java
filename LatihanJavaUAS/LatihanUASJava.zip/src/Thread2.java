public class Thread2 extends Thread1 {
  private float random;

  public Thread2(int choices) {
    super(choices);
  }

  public float getRandom() {
    return this.random;
  }

  public void setRandom(float random) {
    this.random = random;
  }

  @Override
  public void run() {
    int min = 1;
    int max = 99;
    if (getChoices() == 1) {
      random = (float) Math.floor((Math.random() * (max - min + 1) + min));
      System.out.printf("Berapa luas dan keliling segiempat dengan sisi %d?", random);
    } else if (getChoices() == 2) {
      random = (float) Math.floor((Math.random() * (max - min + 1) + min));
      System.out.printf("Berapa luas dan keliling lingkaran dengan sisi %d?", random);
    }
  }
}
