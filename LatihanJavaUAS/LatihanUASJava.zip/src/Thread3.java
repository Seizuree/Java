public class Thread3 extends Thread2 {

  public Thread3(int choices) {
    super(choices);
  }

  Lingkaran x = new Lingkaran(getRandom());
  SegiEmpat y = new SegiEmpat(getRandom());

  @Override
  public void run() {
    if (getChoices() == 1) {
      System.out.printf("Luas=%f dan keliling=%f\n", x.hitungLuas(), x.hitungKeliling());
    } else if (getChoices() == 2) {
      System.out.printf("Luas=%f dan keliling=%f\n", y.hitungLuas(), y.hitungKeliling());
    }
  }
}
