public class SegiEmpat extends Bentuk {
  private float sisi;

  public SegiEmpat(float sisi) {
    this.sisi = sisi;
  }

  public float getsisi() {
    return sisi;
  }

  public void setsisi(float sisi) {
    this.sisi = sisi;
  }

  float hitungLuas() {
    return sisi * sisi;
  }

  float hitungKeliling() {
    return 4 * (sisi);
  }
}
