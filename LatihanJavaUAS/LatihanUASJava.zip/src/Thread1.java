import java.util.Scanner;

public class Thread1 implements Runnable {
  private int choices;

  public Thread1(int choices) {
    this.choices = choices;
  }

  public int getChoices() {
    return this.choices;
  }

  public void setChoices(int choices) {
    this.choices = choices;
  }

  @Override
  public void run() {
    Scanner sc = new Scanner(System.in);
    System.out.print("Masukkan menu [0=Exit; 1=Segiempat; 2=Lingkaran]:");
    do {
      setChoices(sc.nextInt());
    } while (choices < 0 || choices > 3);
    System.out.println(choices);
    sc.close();
  }
}
