public class TestBentuk {
    public static void main(String[] args) throws Exception {
        Thread1 x = new Thread1(0);
        Thread2 y = new Thread2(x.getChoices());
        Thread3 z = new Thread3(x.getChoices());
        Thread thread1 = new Thread(x);
        Thread thread2 = new Thread(y);
        Thread thread3 = new Thread(z);
        thread1.start();
        thread2.start();
        thread3.start();
    }
}
