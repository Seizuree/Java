public class Lingkaran extends Bentuk {
  private float radius;

  public Lingkaran(float radius) {
    this.radius = radius;
  }

  public float getRadius() {
    return this.radius;
  }

  public void setRadius(float radius) {
    this.radius = radius;
  }

  float hitungLuas() {
    return (float) Math.PI * radius * radius;
  }

  float hitungKeliling() {
    return 2 * (float) Math.PI * radius;
  }
}
