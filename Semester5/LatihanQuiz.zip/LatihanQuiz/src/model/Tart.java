package model;

import java.util.ArrayList;

public class Tart extends Confectionary {

	public Tart(String type, String name, String softness, double price, String payment, ArrayList<String> topping) {
		super(type, name, softness, price, payment, topping);
		// TODO Auto-generated constructor stub
	}
}
