package payment;

public class Cash extends Payment {
	public Cash () {}
	
	public Cash(double price) {
		super(price);
		// TODO Auto-generated constructor stub
	}
}
