package payment;

public class Crypto extends Payment {
	public Crypto(double price) {
		super(price);
		// TODO Auto-generated constructor stub
	}
}
