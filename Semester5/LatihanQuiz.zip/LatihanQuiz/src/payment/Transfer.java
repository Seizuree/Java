package payment;

public class Transfer extends Payment {
	public Transfer(double price) {
		super(price);
		// TODO Auto-generated constructor stub
	}
}
